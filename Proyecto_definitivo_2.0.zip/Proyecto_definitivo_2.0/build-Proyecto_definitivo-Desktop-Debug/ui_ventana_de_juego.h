/********************************************************************************
** Form generated from reading UI file 'ventana_de_juego.ui'
**
** Created by: Qt User Interface Compiler version 5.9.5
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VENTANA_DE_JUEGO_H
#define UI_VENTANA_DE_JUEGO_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ventana_de_juego
{
public:
    QWidget *centralWidget;
    QPushButton *pushButton_14;
    QPushButton *pushButton_9;
    QPushButton *pushButton_16;
    QPushButton *pushButton_21;
    QPushButton *pushButton_12;
    QPushButton *pushButton_5;
    QPushButton *pushButton_13;
    QPushButton *pushButton_3;
    QPushButton *pushButton_8;
    QPushButton *pushButton_10;
    QPushButton *pushButton_4;
    QPushButton *pushButton_24;
    QPushButton *pushButton_7;
    QPushButton *pushButton_15;
    QPushButton *pushButton;
    QPushButton *pushButton_6;
    QPushButton *pushButton_18;
    QPushButton *pushButton_26;
    QPushButton *pushButton_20;
    QPushButton *pushButton_23;
    QPushButton *pushButton_19;
    QPushButton *pushButton_17;
    QPushButton *pushButton_2;
    QPushButton *pushButton_22;
    QPushButton *pushButton_25;
    QPushButton *pushButton_11;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *ventana_de_juego)
    {
        if (ventana_de_juego->objectName().isEmpty())
            ventana_de_juego->setObjectName(QStringLiteral("ventana_de_juego"));
        ventana_de_juego->resize(630, 464);
        centralWidget = new QWidget(ventana_de_juego);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        pushButton_14 = new QPushButton(centralWidget);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(260, 10, 89, 25));
        pushButton_14->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_9 = new QPushButton(centralWidget);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(480, 240, 89, 25));
        pushButton_9->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_16 = new QPushButton(centralWidget);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(260, 80, 89, 25));
        pushButton_16->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_21 = new QPushButton(centralWidget);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setGeometry(QRect(490, 240, 89, 25));
        pushButton_21->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_12 = new QPushButton(centralWidget);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(30, 250, 89, 25));
        pushButton_12->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_5 = new QPushButton(centralWidget);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(480, 130, 89, 25));
        pushButton_5->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_13 = new QPushButton(centralWidget);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(250, 80, 89, 25));
        pushButton_13->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_3 = new QPushButton(centralWidget);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(250, 190, 89, 25));
        pushButton_3->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_8 = new QPushButton(centralWidget);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(250, 380, 89, 25));
        pushButton_8->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_10 = new QPushButton(centralWidget);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(110, 340, 89, 25));
        pushButton_10->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_4 = new QPushButton(centralWidget);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(250, 10, 89, 25));
        pushButton_4->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_24 = new QPushButton(centralWidget);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));
        pushButton_24->setGeometry(QRect(40, 250, 89, 25));
        pushButton_24->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_7 = new QPushButton(centralWidget);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(390, 340, 89, 25));
        pushButton_7->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_15 = new QPushButton(centralWidget);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(400, 50, 89, 25));
        pushButton_15->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton = new QPushButton(centralWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(110, 50, 89, 25));
        pushButton->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_6 = new QPushButton(centralWidget);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(390, 50, 89, 25));
        pushButton_6->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_18 = new QPushButton(centralWidget);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(120, 50, 89, 25));
        pushButton_18->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_26 = new QPushButton(centralWidget);
        pushButton_26->setObjectName(QStringLiteral("pushButton_26"));
        pushButton_26->setGeometry(QRect(400, 340, 89, 25));
        pushButton_26->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_20 = new QPushButton(centralWidget);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setGeometry(QRect(40, 130, 89, 25));
        pushButton_20->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_23 = new QPushButton(centralWidget);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));
        pushButton_23->setGeometry(QRect(120, 340, 89, 25));
        pushButton_23->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_19 = new QPushButton(centralWidget);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setGeometry(QRect(270, 190, 89, 25));
        pushButton_19->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_17 = new QPushButton(centralWidget);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(490, 130, 89, 25));
        pushButton_17->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_2 = new QPushButton(centralWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(30, 130, 89, 25));
        pushButton_2->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        pushButton_22 = new QPushButton(centralWidget);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));
        pushButton_22->setGeometry(QRect(260, 380, 89, 25));
        pushButton_22->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_25 = new QPushButton(centralWidget);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));
        pushButton_25->setGeometry(QRect(260, 300, 89, 25));
        pushButton_25->setStyleSheet(QStringLiteral("background-color: rgb(204, 0, 0);"));
        pushButton_11 = new QPushButton(centralWidget);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(250, 300, 89, 25));
        pushButton_11->setStyleSheet(QStringLiteral("background-color: rgb(85, 87, 83);"));
        ventana_de_juego->setCentralWidget(centralWidget);
        pushButton_9->raise();
        pushButton_21->raise();
        pushButton_12->raise();
        pushButton_5->raise();
        pushButton_13->raise();
        pushButton_3->raise();
        pushButton_8->raise();
        pushButton_10->raise();
        pushButton_4->raise();
        pushButton_24->raise();
        pushButton_7->raise();
        pushButton->raise();
        pushButton_6->raise();
        pushButton_18->raise();
        pushButton_26->raise();
        pushButton_23->raise();
        pushButton_19->raise();
        pushButton_17->raise();
        pushButton_2->raise();
        pushButton_22->raise();
        pushButton_11->raise();
        pushButton_25->raise();
        pushButton_16->raise();
        pushButton_14->raise();
        pushButton_15->raise();
        pushButton_20->raise();
        menuBar = new QMenuBar(ventana_de_juego);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 630, 22));
        ventana_de_juego->setMenuBar(menuBar);
        mainToolBar = new QToolBar(ventana_de_juego);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        ventana_de_juego->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(ventana_de_juego);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        ventana_de_juego->setStatusBar(statusBar);

        retranslateUi(ventana_de_juego);

        QMetaObject::connectSlotsByName(ventana_de_juego);
    } // setupUi

    void retranslateUi(QMainWindow *ventana_de_juego)
    {
        ventana_de_juego->setWindowTitle(QApplication::translate("ventana_de_juego", "ventana de juego", Q_NULLPTR));
        pushButton_14->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_16->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_21->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_13->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_3->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_8->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_4->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_24->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_15->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_18->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_26->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_20->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_23->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_19->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_17->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_2->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_22->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_25->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
        pushButton_11->setText(QApplication::translate("ventana_de_juego", "PushButton", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class ventana_de_juego: public Ui_ventana_de_juego {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VENTANA_DE_JUEGO_H
